public class ErroComunicacaoIAException extends Exception {
    public ErroComunicacaoIAException(String mensagem) {
        super(mensagem);
    }
}
