public class PromptInadequadoException extends Exception {
    public PromptInadequadoException(String mensagem) {
        super(mensagem);
    }
}
